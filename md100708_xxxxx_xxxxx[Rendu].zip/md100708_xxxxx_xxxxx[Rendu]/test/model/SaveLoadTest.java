
package model;

import org.junit.Test;

/**
 * Created by neowutran on 22/01/14.
 */
public class SaveLoadTest {

    @Test
    public void testLoad() throws Exception {

        // TODO
    }

    @Test
    public void testSave() throws Exception {

        // TODO
    }
}
