
=======================================================================================================================
Polytech Nice / SI3 / Module POO2-IPA / 2013-2014
=======================================================================================================================

Projet fin semestre

Auteur : Fabien Pinel & Maxime Touroute & Martini Didier
Groupe : SI3 Groupe 1,2,3
Readme : Version : 1.0.0 (Dernière révision 24/01/2014 18:00)

=======================================================================================================================
Executer le programme:
=======================================================================================================================

  Lancer le .jar sans parametres: java -jar ./Project.jar
  Lors de la premiere execution un dossier "MiniProject" contenant le fichier de configuration est crée

=======================================================================================================================
Sources:
=======================================================================================================================

  Les sources sont dans le dossier "src"
  Les tests sont dans le dossier "test"
  L'executable (.jar) est dans le dossier "jar"
  Le point de lancement est la classe "MiniProject.java" du package "demonstrateur"

=======================================================================================================================
Utilisation:
=======================================================================================================================

- La commande "help" affiche l'aide. Elle affiche les commandes disponibles en
fonction du contexte

- La commande "exit" quitte le programme

- Les identifiants de connexion sont disponible en clair(pas taper) dans le fichier data.json

=======================================================================================================================
Infos complementaires
=======================================================================================================================

  - Les erreurs sont loggué dans le fichier log.xml
  - Les fichiers de config et data sont au format JSON
